// my_urlencoded.js
const { Readable } = require('stream');

function myUrlencodedMiddleware(req, res, next) {
  if (req.headers['content-type'] && req.headers['content-type'].includes('application/x-www-form-urlencoded')) {
    const chunks = [];
    req.on('data', (chunk) => {
      chunks.push(chunk);
    });

    req.on('end', () => {
      try {
        const bodyData = Buffer.concat(chunks).toString();
        console.log('Raw URL-encoded data:', bodyData); // Add this debugging statement

        // Treat the entire string as a key
        const urlEncodedData = {};
        urlEncodedData[bodyData] = '';

        console.log('Parsed URL-encoded data:', urlEncodedData); // Add this debugging statement
        req.body = urlEncodedData;
        next();
      } catch (error) {
        next(error);
      }
    });
  } else {
    next();
  }
}

module.exports = myUrlencodedMiddleware;
